console.log('000')
const { Nuxt } = require('nuxt')
console.log('111')
const express = require('express')
console.log('222')
const nuxtConfig = require('./nuxt.config.js')
console.log('333', nuxtConfig)

const nuxt = new Nuxt(nuxtConfig)

console.log('444')

const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware')
const awsServerlessExpress = require('aws-serverless-express')
const app = express()
const server = awsServerlessExpress.createServer(app)

console.log('555')

app.use(awsServerlessExpressMiddleware.eventContext())
app.use(nuxt.render)

console.log('666')

module.exports.main = (event, context) => {
  console.log('777', event, context)
  // workaround for double gzip encoding issue
  // HTTP gzip encoding should be done higher-up via something like CloudFront/CloudFlare
  event.headers['Accept-Encoding'] = 'identity'

  console.log('proxying event=', event)

  awsServerlessExpress.proxy(server, event, context)
}
